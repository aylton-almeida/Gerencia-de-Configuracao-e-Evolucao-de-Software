export interface Course {
  name: string;
  teacher: string;
}
