import { Joi } from "celebrate";
import { Course, CourseSchema } from "./Course";

export interface Student {
  id?: number;
  name: string;
  birth: Date;
  email: string;
  city: string;
  courses?: Course[];
}

export const StudentSchema = {
  id: Joi.number(),
  name: Joi.string().required(),
  birth: Joi.date().required(),
  email: Joi.string().required().email(),
  city: Joi.string().required(),
  courses: Joi.array().items(Joi.object().keys(CourseSchema)),
};
