import { Joi } from "celebrate";

export interface Course {
  name: string;
  teacher: string;
}

export const CourseSchema = {
  id: Joi.number(),
  name: Joi.string().required(),
  teacher: Joi.string().required(),
};
