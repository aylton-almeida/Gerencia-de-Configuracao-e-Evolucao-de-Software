import app from "../src/server";

export default app;
